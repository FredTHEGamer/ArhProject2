#include <stdio.h>
#include <stdbool.h>
#include "platform.h"
#include "xil_printf.h"
#include "xil_cache.h"
#include "xil_mmu.h"
#include "xil_io.h"
#include "xparameters.h"
#include "sleep.h"
#include "xil_exception.h"
#include "xscugic.h"

#define TIMER_BASEADDR XPAR_AXI_TIMER_0_BASEADDR
#define TIMER_INTERRUPT_ID XPAR_FABRIC_AXI_TIMER_0_INTERRUPT_INTR
#define INTC_DEVICE_ID XPAR_PS7_SCUGIC_0_DEVICE_ID

// REGISTER CONSTANTS used to address correct registers
// inside AXI timer IP
#define XIL_AXI_TIMER_TCSR_OFFSET 0x0
#define XIL_AXI_TIMER_TLR_OFFSET 0x4
#define XIL_AXI_TIMER_TCR_OFFSET 0x8
// Constants used to setup AXI Timer registers
#define XIL_AXI_TIMER_CSR_CASC_MASK 0x00000800
#define XIL_AXI_TIMER_CSR_ENABLE_ALL_MASK 0x00000400
#define XIL_AXI_TIMER_CSR_ENABLE_PWM_MASK 0x00000200
#define XIL_AXI_TIMER_CSR_INT_OCCURED_MASK 0x00000100
#define XIL_AXI_TIMER_CSR_ENABLE_TMR_MASK 0x00000080
#define XIL_AXI_TIMER_CSR_ENABLE_INT_MASK 0x00000040
#define XIL_AXI_TIMER_CSR_LOAD_MASK 0x00000020
#define XIL_AXI_TIMER_CSR_AUTO_RELOAD_MASK 0x00000010
#define XIL_AXI_TIMER_CSR_EXT_CAPTURE_MASK 0x00000008
#define XIL_AXI_TIMER_CSR_EXT_GENERATE_MASK 0x00000004
#define XIL_AXI_TIMER_CSR_DOWN_COUNT_MASK 0x00000002
#define XIL_AXI_TIMER_CSR_CAPTURE_MODE_MASK 0x00000001




// Definisane Adrese
#define BRAM_BASEADDR    0x40000000
#define BUTTON_BASEADDR  0x41200000
#define SWITCH_BASEADDR  0x41210000

// Definisanje ekrana
#define SCREEN_WIDTH     320
#define SCREEN_HEIGHT    240

int switch_changed = 0;
int editing_mode = 1;

// Funtion Prototypes
u32 Setup_Interrupt(u32 DeviceId, Xil_InterruptHandler Handler, u32
interrupt_ID);
void Timer_Interrupt_Handler();
static void Setup_And_Start_Timer(unsigned int milliseconds);
// Global Variables
volatile int timer_intr_done = 0;

int buttons = 0;
int button0 = 0;
int switches = 0;
int switch2,switch1,switch0 = 0;
int edit_flag = 0;

void Timer_Interrupt_Handler() {
    // Provera promene na prekidacima
    switches = Xil_In32(SWITCH_BASEADDR);
    switch2 = (switches&0x4) ? 1 : 0;
    switch1 = (switches&0x2) ? 1 : 0;
    switch0 = (switches&0x1) ? 1 : 0;
    buttons = Xil_In32(BUTTON_BASEADDR);



        	        if (switch0 == 0) {
        	            edit_mode();
        	        } else {
        	            animation_mode();
        	        }


}


typedef struct {
    int x, y, radius;
    int R, G, B;
} Circle;

//*void read_switches()
//{
 //switches = Xil_In32(SWITCH_BASEADDR);
 //switch2 = (switches&0x4) ? 1 : 0;
 //switch1 = (switches&0x2) ? 1 : 0;
// switch0 = (switches&0x1) ? 1 : 0;
//}

void read_buttons()
{
 buttons = Xil_In32(BUTTON_BASEADDR);
 button0 = (buttons&0x1) ? 1 : 0;
}

void draw_circle(Circle circle) {
    int x0 = circle.x;
    int y0 = circle.y;
    int radius = circle.radius;
    int R = circle.R;
    int G = circle.G;
    int B = circle.B;

    int x = radius;
    int y = 0;
    int err = 0;

    // This uses the midpoint circle algorithm to draw the circle
    while (x >= y) {
        // Draw the eight octants of the circle
        put_pixel(x0 + x, y0 + y, R, G, B);
        put_pixel(x0 + y, y0 + x, R, G, B);
        put_pixel(x0 - y, y0 + x, R, G, B);
        put_pixel(x0 - x, y0 + y, R, G, B);
        put_pixel(x0 - x, y0 - y, R, G, B);
        put_pixel(x0 - y, y0 - x, R, G, B);
        put_pixel(x0 + y, y0 - x, R, G, B);
        put_pixel(x0 + x, y0 - y, R, G, B);

        if (err <= 0) {
            y += 1;
            err += 2 * y + 1;
        }

        if (err > 0) {
            x -= 1;
            err -= 2 * x + 1;
        }
    }
}

// Definisi broj krugova
    #define NUM_CIRCLES 5

    Circle circles[NUM_CIRCLES] = {
        {32, 40, 25, 65, 138, 216},
        {52, 45, 18, 129, 56, 224},
		{60, 70, 20, 165, 89, 59},
		{120, 75, 35, 45, 229, 134},
        {90, 90, 28, 219, 24, 46}
    };


void edit_mode(){
	for (int i = 0; i < NUM_CIRCLES; i++) {
	        draw_circle(circles[i]);
	    }
	while(buttons & 0x1) {
        clear_circles();
    }
}

void put_pixel(int x, int y, int R, int G, int B) {
    // Boundary checks
    if (x < 0 || x >= SCREEN_WIDTH || y < 0 || y >= SCREEN_HEIGHT) return;

    // Calculate pixel address based on x and y
    int pixel_addr = BRAM_BASEADDR + ((y * SCREEN_WIDTH + x) * 2);

    // Pack the RGB values into a 16-bit integer
    u16 pixel_value = (R << 11) | (G << 5) | B;

    // Write the pixel value to the corresponding address
    Xil_Out16(pixel_addr, pixel_value);
}

void clear_circles() {

    // Background color (e.g., black)
    int background_R = 0;
    int background_G = 0;
    int background_B = 0;

    // Loop over all pixels on the screen
    for (int y = 0; y < SCREEN_HEIGHT; y++) {
        for (int x = 0; x < SCREEN_WIDTH; x++) {
            put_pixel(x, y, background_R, background_G, background_B);
        }
    }
}

void clear_moving_circle(Circle circle) {
    // Pozadinska boja (npr. crna)
    int background_R = 0;
    int background_G = 0;
    int background_B = 0;

    // Iterirajte kroz sve piksele koji su bili u granicama kruga i postavite ih na pozadinsku boju
    for (int y = circle.y - circle.radius; y <= circle.y + circle.radius; y++) {
        for (int x = circle.x - circle.radius; x <= circle.x + circle.radius; x++) {
            // Provjerite je li piksel unutar kruga
            if ((x - circle.x) * (x - circle.x) + (y - circle.y) * (y - circle.y) <= circle.radius * circle.radius) {
                put_pixel(x, y, background_R, background_G, background_B);
            }
        }
    }
}




void animation_mode() {

    // Inicijalizacija kretanja
    int directions[NUM_CIRCLES] = {1, 1, 1, 1, 1};


           if ((switch1 == 0 && switch2 == 0) || (switch1 == 0 && switch2 == 1)) {
               for (int i = 0; i < NUM_CIRCLES; i++) {
                   directions[i] = 1;
               }
           } else if ((switch1 == 1 && switch2 == 0) || (switch1 == 1 && switch2 == 1)) {
               for (int i = 0; i < NUM_CIRCLES; i++) {
                   directions[i] = 2;
               }
           }


           	for(int i = 0; i < NUM_CIRCLES; i++){
           switch (directions[i]) {
                       case 1:
                           clear_moving_circle(circles[i]);
                           circles[i].x += 1;
                           if (circles[i].x - circles[i].radius> SCREEN_WIDTH) {
                        	   circles[i].x  = -circles[i].radius;
                        	   draw_circle(circles[i]);
                        	   usleep(50);
                           }else{
                        	   draw_circle(circles[i]);
                        	   usleep(50);
                           }
                           break;
                       case 2:
                           clear_moving_circle(circles[i]);
                    	   circles[i].x -= 1;
                    	   if (circles[i].x + circles[i].radius < 0) {
                    	           circles[i].x  = SCREEN_WIDTH + circles[i].radius;
                    	           draw_circle(circles[i]);
                    	           usleep(50);
                    	   }else{
                    	           draw_circle(circles[i]);
                    	           usleep(50);
                    	   }
                           break;
                   }
           	}

         }


int main() {
    init_platform();

    Xil_DCacheDisable();
    Xil_ICacheDisable();

    int status;
    int data;

    status = Setup_Interrupt(INTC_DEVICE_ID, (Xil_InterruptHandler)Timer_Interrupt_Handler, TIMER_INTERRUPT_ID);

    while (1) {
    	Setup_And_Start_Timer(5);

    	//Klir interapt flega
    	data = Xil_In32(TIMER_BASEADDR + XIL_AXI_TIMER_TCSR_OFFSET);
    	Xil_Out32(TIMER_BASEADDR + XIL_AXI_TIMER_TCSR_OFFSET, (data | XIL_AXI_TIMER_CSR_INT_OCCURED_MASK));


    	usleep(50000);
    }

    cleanup_platform();

    return 0;
}

u32 Setup_Interrupt(u32 DeviceId, Xil_InterruptHandler Handler, u32 interrupt_ID)
{
 XScuGic_Config *IntcConfig;
 XScuGic INTCInst;
 int status;
 // Extracts informations about processor core based on its ID, and they are
//used to setup interrupts
 IntcConfig = XScuGic_LookupConfig(DeviceId);
 // Initializes processor registers using information extracted in the previous
//step
 status = XScuGic_CfgInitialize(&INTCInst, IntcConfig, IntcConfig->CpuBaseAddress);
 if(status != XST_SUCCESS) return XST_FAILURE;
 status = XScuGic_SelfTest(&INTCInst);
 if (status != XST_SUCCESS) return XST_FAILURE;
 // Connect Timer Handler And Enable Interrupt
 // The processor can have multiple interrupt sources, and we must setup
//trigger and priority
 // for the our interrupt. For this we are using interrupt ID.
 XScuGic_SetPriorityTriggerType(&INTCInst, interrupt_ID, 0xA8, 3);
 // Connects out interrupt with the appropriate ISR (Handler)
 status = XScuGic_Connect(&INTCInst, interrupt_ID, Handler, (void *)&INTCInst);
 if(status != XST_SUCCESS) return XST_FAILURE;
 // Enable interrupt for out device
 XScuGic_Enable(&INTCInst, interrupt_ID);
 //Two lines bellow enable exeptions
 Xil_ExceptionRegisterHandler(XIL_EXCEPTION_ID_INT,
(Xil_ExceptionHandler)XScuGic_InterruptHandler,&INTCInst);
 Xil_ExceptionEnable();
 return XST_SUCCESS;
}


static void Setup_And_Start_Timer(unsigned int milliseconds)
{
// Disable Timer Counter
 unsigned int timer_load;
 unsigned int zero = 0;
 unsigned int data = 0;
 // Line bellow is true if timer is working on 100MHz
 timer_load = zero - milliseconds*100000;
 // Disable timer/counter while configuration is in progress
 data = Xil_In32(TIMER_BASEADDR + XIL_AXI_TIMER_TCSR_OFFSET);
 Xil_Out32(TIMER_BASEADDR + XIL_AXI_TIMER_TCSR_OFFSET, (data &~(XIL_AXI_TIMER_CSR_ENABLE_TMR_MASK)));
 // Set initial value in load register
 Xil_Out32(TIMER_BASEADDR + XIL_AXI_TIMER_TLR_OFFSET, timer_load);
 // Load initial value into counter from load register
 data = Xil_In32(TIMER_BASEADDR + XIL_AXI_TIMER_TCSR_OFFSET);
 Xil_Out32(TIMER_BASEADDR + XIL_AXI_TIMER_TCSR_OFFSET, (data |XIL_AXI_TIMER_CSR_LOAD_MASK));
 // Set LOAD0 bit from the previous step to zero
 data = Xil_In32(TIMER_BASEADDR + XIL_AXI_TIMER_TCSR_OFFSET);
 Xil_Out32(TIMER_BASEADDR + XIL_AXI_TIMER_TCSR_OFFSET, (data &~(XIL_AXI_TIMER_CSR_LOAD_MASK)));
 // Enable interrupts and autoreload, reset should be zero
 Xil_Out32(TIMER_BASEADDR + XIL_AXI_TIMER_TCSR_OFFSET,(XIL_AXI_TIMER_CSR_ENABLE_INT_MASK | XIL_AXI_TIMER_CSR_AUTO_RELOAD_MASK));
 // Start Timer by setting enable signal
 data = Xil_In32(TIMER_BASEADDR + XIL_AXI_TIMER_TCSR_OFFSET);
 Xil_Out32(TIMER_BASEADDR + XIL_AXI_TIMER_TCSR_OFFSET, (data |XIL_AXI_TIMER_CSR_ENABLE_TMR_MASK));
}
